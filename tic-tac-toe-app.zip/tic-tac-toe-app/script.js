
let cells = document.querySelectorAll('.cell');
let currentPlayer = 'X';
let gameState = ["", "", "", "", "", "", "", "", ""];
let statusText = document.getElementById('status');

const winConditions = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
];

cells.forEach(cell => cell.addEventListener('click', cellClicked));

function cellClicked(e) {
    const index = e.target.getAttribute('data-index');
    if (gameState[index] !== "" || checkWinner()) return;

    gameState[index] = currentPlayer;
    e.target.textContent = currentPlayer;

    if (checkWinner()) {
        statusText.textContent = `Player ${currentPlayer} wins!`;
    } else if (!gameState.includes("")) {
        statusText.textContent = "It's a draw!";
    } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        statusText.textContent = `Player ${currentPlayer}'s turn`;
    }
}

function checkWinner() {
    return winConditions.some(condition => {
        return condition.every(index => gameState[index] === currentPlayer);
    });
}

function resetGame() {
    gameState.fill("");
    cells.forEach(cell => cell.textContent = "");
    currentPlayer = 'X';
    statusText.textContent = `Player ${currentPlayer}'s turn`;
}
